/* $Id: op_sguil.h,v 1.2 2005/03/03 21:07:44 bamm Exp $ */

/*
** Copyright (C) 2002-2004 Robert (Bamm) Visscher <bamm@sguil.net> 
**
** This program is distributed under the terms of version 1.0 of the
** Q Public License.  See LICENSE.QPL for further details.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
**
*/

void OpSguil_Init();
